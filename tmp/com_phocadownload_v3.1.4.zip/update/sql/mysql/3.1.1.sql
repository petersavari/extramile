ALTER TABLE `#__phocadownload` ADD COLUMN `tags_string` varchar(255) NOT NULL default '';



