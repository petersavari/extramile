// Greek
plupload.addI18n({
    'Select files' : 'Επιλέξτε Αρχεία',
    'Add files to the upload queue and click the start button.' : 'Προσθήκη αρχείων στην ουρά μεταφόρτωσης',
    'Filename' : 'Όνομα αρχείου',
    'Status' : 'Κατάσταση',
    'Size' : 'Μέγεθος',
    'Add Files' : 'Προσθέστε αρχεία',
    'Stop current upload' : 'Διακοπή τρέχουσας μεταφόρτωσης',
    'Start uploading queue' : 'Εκκίνηση μεταφόρτωσης ουράς αρχείων',
    'Drag files here.' : 'Σύρετε αρχεία εδώ',
    'Start Upload': 'Εκκίνηση μεταφόρτωσης',
    'Uploaded %d/%d files': 'Ανέβηκαν %d/%d αρχεία'
});